plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.adblockershield"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.adblockershield"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
    buildFeatures { buildConfig = true }
    kotlinOptions { jvmTarget = "17" }
}
