package com.example.adblockershield

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("shield", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var packageInput: EditText
    private val vpnRequest = 410

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(Color.rgb(13, 24, 45))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { text = value; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10) }
        val title = text("🛡 AdBlocker Shield Pro", 25f)
        status = text("حالة الحماية: غير مفعّلة", 18f, Color.YELLOW)
        val start = Button(this).apply {
            text = "تشغيل حماية DNS"
            setOnClickListener {
                val prepare = VpnService.prepare(this@MainActivity)
                if (prepare != null) startActivityForResult(prepare, vpnRequest)
                else startVpn()
            }
        }
        val stop = Button(this).apply {
            text = "إيقاف الحماية"
            setOnClickListener { stopService(Intent(this@MainActivity, AdBlockVpnService::class.java)); updateStatus(false) }
        }
        val notificationAccess = Button(this).apply {
            text = "فتح إعداد صلاحية الإشعارات"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val label = text("كتم إشعارات تطبيق محدد", 18f)
        packageInput = EditText(this).apply {
            hint = "مثال: com.example.app"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
        }
        val add = Button(this).apply {
            text = "إضافة إلى قائمة كتم الإشعارات"
            setOnClickListener { addBlockedPackage() }
        }
        val list = TextView(this).apply { textSize = 13f; setTextColor(Color.LTGRAY) }
        val refresh = Button(this).apply {
            text = "عرض التطبيقات المكتومة"
            setOnClickListener { list.text = "القائمة: " + blockedPackages().joinToString().ifBlank { "فارغة" } }
        }
        val info = text(
            "يعمل الحظر عبر DNS للنطاقات المعروفة. قد تتجاوز بعض التطبيقات الحظر باستخدام DNS مشفّر أو إعلانات من نفس نطاق المحتوى.",
            13f, Color.LTGRAY
        )
        root.addView(title); root.addView(status)
        root.addView(start); root.addView(stop)
        root.addView(notificationAccess); root.addView(label)
        root.addView(packageInput); root.addView(add); root.addView(refresh); root.addView(list); root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
        updateStatus(prefs.getBoolean("vpn_enabled", false))
    }

    private fun startVpn() {
        val i = Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START)
        startForegroundService(i)
        updateStatus(true)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequest && resultCode == RESULT_OK) startVpn()
    }

    private fun addBlockedPackage() {
        val name = packageInput.text.toString().trim()
        if (name.isBlank() || !name.contains(".")) {
            Toast.makeText(this, "أدخل اسم الحزمة بشكل صحيح", Toast.LENGTH_SHORT).show()
            return
        }
        val set = blockedPackages().toMutableSet()
        set.add(name)
        prefs.edit().putStringSet("blocked_packages", set).apply()
        packageInput.text.clear()
        Toast.makeText(this, "تمت الإضافة", Toast.LENGTH_SHORT).show()
    }

    private fun blockedPackages(): Set<String> =
        prefs.getStringSet("blocked_packages", emptySet())?.toSet() ?: emptySet()

    private fun updateStatus(on: Boolean) {
        status.text = if (on) "حالة الحماية: قيد التشغيل" else "حالة الحماية: متوقفة"
        status.setTextColor(if (on) Color.GREEN else Color.YELLOW)
    }
}
