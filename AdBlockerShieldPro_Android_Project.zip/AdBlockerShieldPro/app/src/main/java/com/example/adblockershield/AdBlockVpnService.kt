package com.example.adblockershield

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.Build
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class AdBlockVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.example.adblockershield.START"
        const val ACTION_STOP = "com.example.adblockershield.STOP"
        private const val CHANNEL = "adblock_vpn"
        private const val DNS_IP = "10.77.0.2"
        private const val UPSTREAM_DNS = "1.1.1.1"
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private val blockedDomains = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com",
        "popads.net", "popcash.net", "adsterra.com", "smartadserver.com"
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopVpn()
            else -> startVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (running.get()) return
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
        } else Notification.Builder(this)
        startForeground(7, notification.setContentTitle("AdBlocker Shield Pro")
            .setContentText("حماية DNS المحلية تعمل")
            .setSmallIcon(android.R.drawable.ic_secure)
            .build())

        try {
            val builder = Builder()
                .setSession("AdBlocker Shield Pro")
                .addAddress("10.77.0.1", 32)
                .addDnsServer(InetAddress.getByName(DNS_IP))
                .addRoute(DNS_IP, 32)
                .setMtu(1500)
            tun = builder.establish()
            if (tun == null) { stopSelf(); return }
            running.set(true)
            getSharedPreferences("shield", MODE_PRIVATE).edit().putBoolean("vpn_enabled", true).apply()
            thread(name = "dns-filter") { processPackets() }
        } catch (_: Exception) {
            stopVpn()
        }
    }

    private fun processPackets() {
        val input = FileInputStream(tun!!.fileDescriptor)
        val output = FileOutputStream(tun!!.fileDescriptor)
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val length = input.read(buffer)
                if (length <= 0) continue
                val packet = buffer.copyOf(length)
                val parsed = parseDnsPacket(packet) ?: continue
                val responseDns = if (isBlocked(parsed.domain)) {
                    blockedCount()
                    makeNxDomain(parsed.dns)
                } else {
                    forwardDns(parsed.dns) ?: continue
                }
                val responsePacket = buildIpv4UdpResponse(
                    packet, parsed.ipHeaderLength, parsed.udpLength, responseDns
                ) ?: continue
                output.write(responsePacket)
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private data class DnsRequest(
        val domain: String, val dns: ByteArray, val ipHeaderLength: Int, val udpLength: Int
    )

    private fun parseDnsPacket(p: ByteArray): DnsRequest? {
        if (p.size < 28 || (p[0].toInt() ushr 4 and 0xF) != 4) return null
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (p.size < ihl + 8) return null
        if (p[9].toInt() and 0xFF != 17) return null
        val destPort = u16(p, ihl + 2)
        if (destPort != 53) return null
        val udpLen = u16(p, ihl + 4)
        if (udpLen < 20 || p.size < ihl + udpLen) return null
        val dns = p.copyOfRange(ihl + 8, ihl + udpLen)
        if (dns.size < 17) return null
        val domain = readQName(dns) ?: return null
        return DnsRequest(domain, dns, ihl, udpLen)
    }

    private fun readQName(d: ByteArray): String? {
        var i = 12
        val labels = mutableListOf<String>()
        while (i < d.size) {
            val n = d[i].toInt() and 0xFF
            i++
            if (n == 0) break
            if (n > 63 || i + n > d.size) return null
            labels.add(String(d, i, n, Charsets.US_ASCII).lowercase())
            i += n
        }
        return labels.joinToString(".").takeIf { it.isNotBlank() }
    }

    private fun isBlocked(domain: String): Boolean =
        blockedDomains.any { domain == it || domain.endsWith(".$it") }

    private fun makeNxDomain(query: ByteArray): ByteArray {
        var end = 12
        while (end < query.size) {
            val n = query[end].toInt() and 0xFF
            end++
            if (n == 0) break
            if (n > 63 || end + n > query.size) return query
            end += n
        }
        end += 4
        if (end > query.size) return query
        val out = query.copyOfRange(0, end)
        val flags = ((u16(query, 2) or 0x8000 or 0x0080 or 0x0003) and 0xFFF3)
        put16(out, 2, flags)
        put16(out, 4, 1)
        put16(out, 6, 0); put16(out, 8, 0); put16(out, 10, 0)
        return out
    }

    private fun forwardDns(dns: ByteArray): ByteArray? {
        return try {
            DatagramSocket().use { socket ->
                protect(socket)
                socket.soTimeout = 2500
                val address = InetAddress.getByName(UPSTREAM_DNS)
                socket.send(DatagramPacket(dns, dns.size, address, 53))
                val buf = ByteArray(4096)
                val response = DatagramPacket(buf, buf.size)
                socket.receive(response)
                buf.copyOf(response.length)
            }
        } catch (_: Exception) { null }
    }

    private fun buildIpv4UdpResponse(
        request: ByteArray, ihl: Int, oldUdpLen: Int, dns: ByteArray
    ): ByteArray? {
        if (request.size < ihl + 8) return null
        val srcPort = u16(request, ihl)
        val dstPort = u16(request, ihl + 2)
        val srcIp = request.copyOfRange(12, 16)
        val dstIp = request.copyOfRange(16, 20)
        val udpLen = 8 + dns.size
        val total = 20 + udpLen
        val out = ByteArray(total)
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, total)
        put16(out, 4, 0)
        put16(out, 6, 0x4000)
        out[8] = 64
        out[9] = 17
        // response source is the DNS virtual address (original destination)
        System.arraycopy(dstIp, 0, out, 12, 4)
        System.arraycopy(srcIp, 0, out, 16, 4)
        put16(out, 10, checksum(out, 0, 20))
        put16(out, 20, dstPort)
        put16(out, 22, srcPort)
        put16(out, 24, udpLen)
        System.arraycopy(dns, 0, out, 28, dns.size)
        // UDP checksum 0 is valid for IPv4.
        return out
    }

    private fun blockedCount() {
        val p = getSharedPreferences("shield", MODE_PRIVATE)
        p.edit().putLong("blocked_count", p.getLong("blocked_count", 0) + 1).apply()
    }

    private fun u16(b: ByteArray, i: Int): Int =
        ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

    private fun put16(b: ByteArray, i: Int, v: Int) {
        b[i] = (v ushr 8).toByte(); b[i + 1] = v.toByte()
    }

    private fun checksum(b: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length - 1) {
            sum += (((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (length % 2 == 1) sum += ((b[offset + length - 1].toInt() and 0xFF) shl 8).toLong()
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "AdBlocker VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun stopVpn() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        getSharedPreferences("shield", MODE_PRIVATE).edit().putBoolean("vpn_enabled", false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }
}
