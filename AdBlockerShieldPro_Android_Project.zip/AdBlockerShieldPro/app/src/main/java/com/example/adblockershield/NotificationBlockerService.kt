package com.example.adblockershield

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationBlockerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val prefs = getSharedPreferences("shield", MODE_PRIVATE)
        val blocked = prefs.getStringSet("blocked_packages", emptySet()) ?: emptySet()
        if (sbn.packageName in blocked) {
            cancelNotification(sbn.key)
        }
    }
}
